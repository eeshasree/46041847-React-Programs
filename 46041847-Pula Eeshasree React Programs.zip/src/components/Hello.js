import React from 'react'

const Hello = () => {
    //return (
      //  <div>
        //    <h1>Hello Eesha</h1>
        // </div>
    // )
    return React.createElement('div', null, 'Hello Eesha')
}

export default Hello